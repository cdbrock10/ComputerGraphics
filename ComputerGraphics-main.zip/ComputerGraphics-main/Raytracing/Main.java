import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.awt.*;
import javax.imageio.ImageIO;


class Main {
    public static void main(String args[]) {
        System.out.println("hello world");


        try {

            var rayTracer = new RayTracer(new Light(), new Camera(), new Mesh());
            var bufferedImage = rayTracer.render(256, 256);

            ImageIO.write(bufferedImage, "PNG", new File("./out.png"));
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }


    }
}