public class Camera {
    private Vector3 origin;
    private Vector3 lookAt;
    private Vector3 lookUp;

    public Camera(Vector3 origin, Vector3 lookAt, Vector3 lookUp)
    {
        this.origin = origin;
        this.lookAt = lookAt;
        this.lookUp = lookUp;
    }
}
