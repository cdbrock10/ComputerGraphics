

public class Mesh {
    private Material material;
    private Triangle[] triangles;

    public Mesh(Material material, Triangle[] traingles)
    {
        this.material = material;
        this.triangles = triangles;
    }
}
