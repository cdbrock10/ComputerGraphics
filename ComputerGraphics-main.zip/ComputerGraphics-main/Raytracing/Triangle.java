

public class Triangle {
    private Vector3 one;
    private Vector3 two;
    private Vector3 three;

    public Triangle(Vector3 one, Vector3 two, Vector3 three)
    {
        this.one = one;
        this.two = two;
        this.three = three;
    }
}
