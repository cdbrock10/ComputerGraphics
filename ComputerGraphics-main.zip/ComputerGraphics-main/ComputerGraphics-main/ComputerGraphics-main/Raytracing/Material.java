

public class Material {
    private Vector3 color;

    public Material(Vector3 color)
    {
        this.color = color;
    }
}
