public class Material {

  public Vector3 color;
  public Material(Vector3 color){
    this.color = color;
  }
  
}
