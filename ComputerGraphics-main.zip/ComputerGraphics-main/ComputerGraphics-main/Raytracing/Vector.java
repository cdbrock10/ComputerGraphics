public class Vector extends Point {

  public Vector(double one, double two, double three){
    super(one, two, three);
  }
  
}
