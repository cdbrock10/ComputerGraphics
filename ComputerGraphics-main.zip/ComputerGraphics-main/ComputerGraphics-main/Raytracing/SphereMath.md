Definition of a sphere
$(p-c)^2=R^2$

Definition of  ray
$r_o+r_d\cdot t$

Combining
$(r_o+r_d\cdot t - c)^2-R^2=0$

$(r_o+r_d\cdot t - c)^2-R^2=0$