public class Light {

    private Vector3 direction;
    private Vector3 color;

    public Light(Vector3 direction, Vector3 color)
    {
        this.direction = direction;
        this.color = color;
    }
}
