public class Point {

  double x, y, z;

  public Point(double x, double y, double z) {
    this.x = x;
    this.y = y;
    this.z = z;
  }

  public Point normalize() {
    var length = this.length();
    x /= length;
    y /= length;
    z /= length;
    return this;
  }

  public Point normalizeCopy() {
    var length = this.length();
    return new Point(x/length, y/length, z/length);
  }

  public double length() {
    return Math.sqrt(this.lengthSquared());
  }

  public double lengthSquared() {
    return x * x + y * y + z * z;
  }

  public double dot(Point other)
  {
      double product = this.x * other.x + this.y * other.y + this.z * other.z;
      return product;
  }

  public Point cross (Point Other)
  {
    var x = this.y*other.z-this.z*other.y;
    var y = this.z*other.x-this.x*other.z;
    var z = this.x*other.y-this.y*other.x;

    return new Point(x,y,z);
  }

  @Override
  public boolean equals(Object obj)
  {
    var other = ((Point) obj);
    return this.x == other.x && this.y == other.y && this.z == other.z;
  }
}
