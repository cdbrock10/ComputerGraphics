public class TAndNormal {
  public float t;
  public Vector3 normal;

  public TAndNormal(float t, Vector3 normal){
    this.t = t;
    this.normal = normal;
  }
  
}
