public interface Geometry {

  TAndNormal intersect(Ray ray);
  
}
